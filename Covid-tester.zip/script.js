function Submit(){
  const usual = ['#usual1','#usual2','#usual3','#usual4','#usual5','#usual6','#usual7'];
  const critical=['#critical1','#critical2','#critical3','#critical4','#critical5','#critical6']
  const sometime=['#sometime1','#sometime2','#sometime3']
  const underlining=document.querySelector('#underline');
  const distance=document.querySelector('#distance');
  awnser=document.getElementById("awnser");

  
  
  var some=0;
  for (let i = 0; i < sometime.length; i++) {
    if(document.querySelector(sometime[i]).checked){
      some++;
    }
  }

  if(some>=2){
    awnser.innerHTML="Quarintine for 5 days, if you still show the same symptoms or more after 5 days then get tested.";
  }

  for (let i = 0; i < usual.length; i++) {
    if(document.querySelector(usual[i]).checked){
      awnser.innerHTML="Quarintine for 5 days, if you still show the same symptoms or more after 5 days then get tested.";
    }
  }
  
  for (let i = 0; i < sometime.length; i++) {
    if(document.querySelector(sometime[i]).checked){
      some++;
    }
  }

  if(some>=2 && underlining.checked || some>=2 && distance.checked){
    awnser.innerHTML="Get tested immediately";
  }
  for (let i = 0; i < usual.length; i++) {
    if(document.querySelector(usual[i]).checked && underlining.checked || document.querySelector(usual[i]).checked && distance.checked){
      awnser.innerHTML="Get tested immediately";
    }
  }

  for (let i = 0; i < critical.length; i++) {
    if(document.querySelector(critical[i]).checked){
      awnser.innerHTML="Go to the ECR immediatley";
    }
  }

  

  


  
}

